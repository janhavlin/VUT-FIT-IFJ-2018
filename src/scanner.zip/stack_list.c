#include "stack_list.h"

tStackLPtr sLInit( void ){
	tStackLPtr stack = (tStackLPtr) malloc(sizeof(tStackL));
	if(stack != NULL){
		
		stack->first = (tStackIPtr) malloc(sizeof(tStackI));
		
		if(stack->first != NULL){
			stack->first->pred 		= NULL;	
			stack->first->next 		= NULL;
			stack->first->type 		= (char *) calloc(4, sizeof(char));
			stack->first->IdName 	= (char *) calloc(2, sizeof(char));

			if(stack->first->IdName == NULL){
				ifjErrorPrint("stack_list ERROR in sLInit: Can't allocate 'IdName' int stack. ERROR %d\n", ERR_RUNTIME);
				return NULL; 
			}
			if(stack->first->type == NULL){
				ifjErrorPrint("stack_list ERROR in sLInit: Can't allocate string 'type' in stack. ERROR %d\n", ERR_RUNTIME);
				return NULL;
			}

			stack->first->IdName = strcpy(stack->first->IdName, "$\0");	
			stack->first->type = strcpy(stack->first->IdName, "EOS\0");		//EOS End Of Stack
			stack->top = stack->first;

			stack->top->next = NULL;
			stack->top->pred = NULL;	
			return stack;	
		}
		else{
			ifjErrorPrint("stack_list ERROR in sLInit: Can't allocate item 'first'. ERROR %d\n", ERR_RUNTIME);
			return NULL;
		}
	}
	else{
		ifjErrorPrint("stack_list ERROR in sLInit: Can't allocate whole struct. ERROR %d\n", ERR_RUNTIME);
		return NULL;
	}
}

bool sLDelete( tStackLPtr stack ){
	if(stack != NULL){
		tStackIPtr help = stack->first;
		tStackIPtr delete = NULL;
		
		while(help->next != NULL)	// the most right item of list
			help = help->next;
		
		while(help != stack->first){	
			delete = help;
			help = help->pred;
			
			if(delete->IdName != NULL)
				free(delete->IdName);

			if(stack->top->type != NULL)
				free(delete->type);
			
			free(delete);	
		}

		if(stack->first->IdName != NULL)
			free(stack->first->IdName);
		
		if(stack->first->type != NULL)
			free(stack->first->type);

		free(stack->first);

		stack->first = NULL;
		stack->top = NULL;
		
		free(stack);	
		return 1;
	}
	else
		return 0;
}


bool sLEmpty( tStackLPtr stack ){	// return 1 if stack is empty
	if(stack != NULL)
		return ( (stack->top != NULL) || (stack->first == NULL) );
	return 0;
}


tStackIPtr sLTop( tStackLPtr stack ){
	if(stack != NULL)
		return stack->top;
	else
		return NULL;
}


tStackIPtr sLPop( tStackLPtr stack ){
	if( !sLEmpty(stack) ){
		tStackIPtr res = stack->top;
		stack->top = stack->top->pred;
		return res;
	}
	
	return NULL;
}

			
				

void sLPush( tStackLPtr stack, char *type, char *name ){
	if(stack != NULL){
		tStackIPtr New 	= (tStackIPtr) malloc(sizeof(tStackI));
		
		New->IdName 	= (char *) calloc(strlen(name)+1, sizeof(char));
		New->type 		= (char *) calloc(strlen(type)+1, sizeof(char));

		New->IdName 	= strcpy(New->IdName, name);
		New->type 		= strcpy(New->IdName, type);
		
		if(New == NULL){
			ifjErrorPrint("stack_list ERROR in sLPush: Can't allocate item 'New' in stack. ERROR %d\n", ERR_RUNTIME);
			return;
		}
		if(New->IdName == NULL){
			ifjErrorPrint("stack_list ERROR in sLPush: Can't allocate item 'Idname' in New. ERROR %d\n", ERR_RUNTIME);
			return;
		}

		if( New->type == NULL){
			ifjErrorPrint("stack_list ERROR in sLPush: Can't allocate item 'type' in New. ERROR %d\n", ERR_RUNTIME);
		}

		tStackIPtr Help;

		if(stack->top->next != NULL){
			Help = stack->top->next;
			stack->top->next = New;
			
			New->next = Help;
			Help->pred = New;

			New->pred = stack->top;
			stack->top = New;
		}

		else{	// top is really last item in list
			stack->top->next = New;
			New->pred = stack->top;

			stack->top = New;
		}
	}
}

